import matplotlib.pyplot as plt
import numpy as np
import nmrglue as ng
#####################################################################
# 2D ploting
    
def subp(axs,dic,data,tit,contour,cmap,lim,data_1=np.zeros((2,2)),cmap_1=plt.cm.spring):
    cl = contour[0] * contour[1] ** np.arange(contour[2])
    uc_x = ng.pipe.make_uc(dic, data, dim=1)
    ppm_x = uc_x.ppm_scale()
    ppm_x_0, ppm_x_1 = uc_x.ppm_limits()
    uc_y = ng.pipe.make_uc(dic, data, dim=0)
    ppm_y = uc_y.ppm_scale()
    ppm_y_0, ppm_y_1 = uc_y.ppm_limits()

    axs.contour(data, cl, cmap=cmap[0],extent=(ppm_x_0, ppm_x_1, ppm_y_0, ppm_y_1))
    axs.contour(-data, cl, cmap=cmap[1],extent=(ppm_x_0, ppm_x_1, ppm_y_0, ppm_y_1))
    if data_1.all() != 0:
        axs.contour(data_1, cl, cmap=cmap_1,extent=(ppm_x_0, ppm_x_1, ppm_y_0, ppm_y_1))

    # decorate the axes
    axs.set_ylabel(dic["FDF1LABEL"]+" (ppm)")
    axs.set_xlabel(dic["FDF2LABEL"]+" (ppm)")
    axs.set_title(tit,y=1,pad=-25, loc='left')
    axs.set_xlim(lim[0], lim[1])
    axs.set_ylim(lim[2], lim[3])
    axs.locator_params(axis="x", nbins=4)
    axs.locator_params(axis="y", nbins=4)

#####################################################################
#Metric
def CC_RMSD(Ref,Pred,Noise_threshold,RMSD_threshold=1):
    P = Pred.flatten()/np.max(Ref)
    R = Ref.flatten()/np.max(Ref)
    x = R[(np.abs(R)>Noise_threshold) | (np.abs(P)>Noise_threshold)]
    y = P[(np.abs(R)>Noise_threshold) | (np.abs(P)>Noise_threshold)]
    CC = np.corrcoef(x, y)[0,1]
    X = x[(np.abs(x)<RMSD_threshold) | (np.abs(y)<RMSD_threshold)]
    Y = y[(np.abs(x)<RMSD_threshold) | (np.abs(y)<RMSD_threshold)]
    RMSD = np.sqrt(((X - Y) ** 2).mean())
    return CC, RMSD

def CC_RMSD_plt(Label,CC,RMSD,color,Mode = ''):
    fig, axs = plt.subplots(1, 2,figsize=(12,6))

    axs[0].bar(Label, np.mean(CC,axis =1),yerr=np.std(CC,axis =1), capsize=10, color=color)
    ylim_m = CC.min()-0.1*(CC.max()-CC.min())
    ylim_M = CC.max()+0.1*(CC.max()-CC.min())
    axs[0].set(ylim=[ylim_m,ylim_M])
    axs[0].grid()
    axs[0].set(ylabel='$R_S^2$')
    axs[0].locator_params(axis="y", nbins=4)
    axs[0].tick_params(axis='x', labelrotation = 90)
        
    axs[1].bar(Label, np.mean(RMSD,axis =1),yerr=np.std(RMSD,axis =1), capsize=10, color=color)
    ylim_m = RMSD.min()-0.1*(RMSD.max()-RMSD.min())
    ylim_M = RMSD.max()+0.1*(RMSD.max()-RMSD.min())
    axs[1].set(ylim=[ylim_m,ylim_M])
    axs[1].grid()
    axs[1].set(ylabel='RMSD')
    axs[1].yaxis.set_label_position("right")
    axs[1].yaxis.tick_right()
    axs[1].locator_params(axis="y", nbins=4)
    axs[1].tick_params(axis='x', labelrotation = 90)

    plt.subplots_adjust(wspace=0.05, hspace=0.05)
    if Mode != '':
        fig.savefig(Mode,bbox_inches='tight')
