import numpy as np
import Proc_2D as pr

def update_S(i, S, Th, I):
    ind = np.unravel_index(np.argmax(np.abs(S), axis=None), S.shape)
    S -= Th * (1 - (i + 1) / I) * S[ind]
    if S[ind] >= 0: S[S < 0] = 0
    else: S[S > 0] = 0
    return S

def NUS_US(S_input,NUS,I=200,Th=1,e=0):
    S_output = np.zeros_like(S_input)
    S = np.array(S_input)
    for i in range(I):
        S_output += update_S(i, S, Th, I)
        S = S_input - pr.convertors.US_to_NUS(S_output,NUS)
        if np.linalg.norm(S) < e:
            break
    return S_output 

def E_US(S_input,I=200,Th=1,e=0):
    S_output = np.zeros_like(S_input)
    S = np.array(S_input)
    for i in range(I):
        S_output += update_S(i, S, Th, I)
        S = S_input - pr.convertors.VE_to_E(S_output)
        if np.linalg.norm(S) < e:
            break
    return S_output 

def AE_US(S_input,I=200,Th=1,e=0):
    S_output = np.zeros_like(S_input)
    S = np.array(S_input)
    for i in range(I):
        S_output += update_S(i, S, Th, I)
        S = S_input - pr.convertors.VE_to_AE(S_output)
        if np.linalg.norm(S) < e:
            break
    return S_output 
