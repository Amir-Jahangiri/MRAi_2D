import numpy as np

#####################################################################
#Metric
def CC_RMSD(Ref,Pred,Noise_threshold,RMSD_threshold=1):
    P = Pred.flatten()/np.max(Ref)
    R = Ref.flatten()/np.max(Ref)
    x = R[(np.abs(R)>Noise_threshold) | (np.abs(P)>Noise_threshold)]
    y = P[(np.abs(R)>Noise_threshold) | (np.abs(P)>Noise_threshold)]
    CC = np.corrcoef(x, y)[0,1]
    X = x[(np.abs(x)<RMSD_threshold) | (np.abs(y)<RMSD_threshold)]
    Y = y[(np.abs(x)<RMSD_threshold) | (np.abs(y)<RMSD_threshold)]
    RMSD = np.sqrt(((X - Y) ** 2).mean())
    return CC, RMSD
