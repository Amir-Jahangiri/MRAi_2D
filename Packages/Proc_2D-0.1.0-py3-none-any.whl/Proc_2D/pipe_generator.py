import nmrglue as ng
import numpy as np
import gc
#####################################################################
# process the direct dimension
def FT_DD(dic_fid,data_fid):
    dic, data = ng.pipe_proc.sp(dic_fid.copy(), data_fid, off=0.48, end=0.95, pow=2, c=0.5)
    dic, data = ng.pipe_proc.zf(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data)
    dic_ft, data_ft = ng.pipe_proc.di(dic, data)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

# process the indirect dimension
def FT_ID(dic_fid,data_fid,MODE=0):
    dic, data = ng.pipe_proc.tp(dic_fid.copy(), data_fid)
    if MODE ==0: dic, data = ng.pipe_proc.sp(dic, data, off=0.48, end=0.95, pow=2, c=0.5)
    dic, data = ng.pipe_proc.zf(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data)
    dic, data = ng.pipe_proc.di(dic, data)
    dic_ft, data_ft = ng.pipe_proc.tp(dic, data)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

def FT_processing(dic_fid,data_fid,MODE=0):
    dic, data = FT_DD(dic_fid,data_fid)
    dic_ft, data_ft = FT_ID(dic, data,MODE)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

# invert process the indirect dimension
def iFT_ID(dic_fid,data_fid,MODE=0):
    dic, data = ng.pipe_proc.tp(dic_fid.copy(), data_fid)
    dic, data = ng.pipe_proc.ht(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data, inv=True)
    dic, data = ng.pipe_proc.zf(dic, data, inv=True)
    if MODE ==0: dic, data = ng.pipe_proc.sp(dic, data, inv=True, hdr=True)
    dic_ft, data = ng.pipe_proc.tp(dic, data)
    data_ft = np.zeros((2*data.shape[0],data.shape[1]),dtype='float32')
    for i in range(len(data)):
        data_ft[2*i+1,:] = data[i,:].imag
        data_ft[2*i,:] = data[i,:].real
    del dic, data
    gc.collect()
    return dic_ft, data_ft
#####################################################################
def parameters_creator(J, a_range, omega_range, tau_range, phi_range):
    Dim = tau_range.shape[0]
    a = np.random.uniform(a_range[0], a_range[1], (J,))
    omega = np.random.uniform(omega_range[0], omega_range[1],(J,Dim))
    tau = np.random.uniform(tau_range[0,0], tau_range[0,1], (J,Dim))
    for i in range(1,Dim):
        tau[:,i] = np.random.uniform(tau_range[i,0],tau_range[i,1], J)
    phi = np.random.normal(phi_range[0], phi_range[1], (J,Dim))
    del Dim
    gc.collect()
    return a, omega, tau, phi

def FID_creator(J, a, omega, tau, phi, N_O_P):
    def fid(OM,TA,PH,t):
        return np.exp(1j*(2*np.pi*OM*t+PH))*np.exp(-t*TA)
    t_0 = np.arange(0, N_O_P[0])
    t_1 = np.arange(0, N_O_P[1])
    X = np.zeros((2*N_O_P[0],N_O_P[1]), dtype=complex)
    for j in range(J):
        X_0 = fid(omega[j,0],tau[j,0],phi[j,0],t_0)
        X_1 = a[j]*fid(omega[j,1],tau[j,1],phi[j,1],t_1)
        for k in range(N_O_P[0]):  
            X[2*k,:] += X_0.real[k]*X_1
            X[2*k+1,:] += X_0.imag[k]*X_1
    del t_0, t_1, X_0, X_1, j,k
    gc.collect()
    return X

def noise_creator(N_O_P):
    size = 2*np.array(N_O_P)
    size[-1] *= 0.5
    noise = np.random.normal(size=size.astype(int)) +1j*np.random.normal(size=size.astype(int))
    del size
    gc.collect()
    return noise

def data_Full(N_O_P,J,a_range,omega_range,tau_range,phi_range,SNR,MODE=0):
    a, omega, tau, phi = parameters_creator(J, a_range, omega_range, tau_range, phi_range)
    FID = FID_creator(J, a, omega, tau, phi, N_O_P)
    noise = noise_creator(N_O_P)
    _,S = FT_processing(dic_generator(N_O_P),FID,MODE)
    _,N = FT_processing(dic_generator(N_O_P),noise,MODE)
    N *= np.max(S)/(np.std(N)*SNR)
    S += N
    del a, omega, tau, phi, FID, noise, N
    gc.collect()
    return S

#####################################################################

def dic_generator(N_O_P):
    dic = {'FDREALSIZE': N_O_P[1],   'FDDIMCOUNT': 2.0, 'FDFILECOUNT': 1,    'FD2DVIRGIN': 1.0,  'FD2DPHASE': 2.0,
           'FDFLTFORMAT': 4008636160.0,'FDFLTORDER': 2.3450000286102295,'FDDIMORDER':[2.0, 1.0, 3.0, 4.0],
           'FDDIMORDER1': 2.0, 'FDDIMORDER2': 1.0, 'FDDIMORDER3': 3.0, 'FDDIMORDER4': 4.0,
           'FDF1LABEL': 'ID',           'FDF2LABEL': 'DD',          'FDF3LABEL': 'Z',       'FDF4LABEL': 'A',
           'FDSPECNUM': 2*N_O_P[0],     'FDSIZE': N_O_P[1],         'FDF3SIZE': 1.0,        'FDF4SIZE': 1.0,
           'FDF1CENTER':int(N_O_P[0]/2)+1,'FDF2CENTER':int(N_O_P[1]/2)+1,'FDF3CENTER': 1.0, 'FDF4CENTER': 1.0,
           'FDF1TDSIZE': N_O_P[0],      'FDF2TDSIZE': N_O_P[1],     'FDF3TDSIZE': 0.0,      'FDF4TDSIZE': 0.0,
           'FDF1SW': 1,                 'FDF2SW': 1,                'FDF3SW': 0.0,          'FDF4SW': 0.0,
           'FDF1APOD': N_O_P[0],        'FDF2APOD': N_O_P[1],       'FDF3APOD': 0.0,        'FDF4APOD': 0.0,
           'FDF1OBS':1,                 'FDF2OBS': 1,               'FDF3OBS': 0.0,         'FDF4OBS': 0.0,
           'FDF1AQSIGN': 2.0,           'FDF2AQSIGN': 0.0,          'FDF3AQSIGN': 0.0,      'FDF4AQSIGN': 0.0,
           'FDF1ORIG': 0,               'FDF2ORIG':0.0,             'FDF3ORIG': 0.0,        'FDF4ORIG': 0.0,
           'FDF1CAR': 0.0,              'FDF2CAR': 0.0,             'FDF3CAR': 0.0,         'FDF4CAR': 0.0,
           'FDF1QUADFLAG': 0.0,         'FDF2QUADFLAG': 0.0,        'FDF3QUADFLAG': 1.0,    'FDF4QUADFLAG': 1.0,
           'FDF1P0': 0.0,               'FDF2P0': 0,                'FDF3P0': 0.0,          'FDF4P0': 0.0,
           'FDF1P1': 0.0,               'FDF2P1': 0,                'FDF3P1': 0.0,          'FDF4P1': 0.0,
           'FDF1APODQ1': 0.0,           'FDF2APODQ1': 0.0,          'FDF3APODQ1': 0.0,      'FDF4APODQ1': 0.0,
           'FDF1APODQ2': 0.0,           'FDF2APODQ2': 0.0,          'FDF3APODQ2': 0.0,      'FDF4APODQ2': 0.0,
           'FDF1APODQ3': 0.0,           'FDF2APODQ3': 0.0,          'FDF3APODQ3': 0.0,      'FDF4APODQ3': 0.0,
           'FDF1APODCODE': 0,           'FDF2APODCODE': 0,          'FDF3APODCODE': 0,      'FDF4APODCODE': 0,
           'FDF1FTSIZE': 0.0,           'FDF2FTSIZE': 0.0,          'FDF3FTSIZE': 0.0,      'FDF4FTSIZE': 0.0,
           'FDF1X1': 0.0,               'FDF2X1': 0.0,              'FDF3X1': 0.0,          'FDF4X1': 0.0,
           'FDF1C1': 0.0,               'FDF2C1': 0.0,              'FDF3C1': 0.0,          'FDF4C1': 0.0,
           'FDF1ZF': 0.0,               'FDF2ZF': 0.0,              'FDF3ZF': 0.0,          'FDF4ZF': 0.0,
           'FDF1OFFPPM': 0.0,           'FDF2OFFPPM': 0.0,          'FDF3OFFPPM': 0.0,      'FDF4OFFPPM': 0.0,
           'FDF1UNITS': 0.0,            'FDF2UNITS': 0.0,           'FDF3UNITS': 0.0,       'FDF4UNITS': 0.0,
           'FDF1FTFLAG': 0.0,           'FDF2FTFLAG': 0.0,          'FDF3FTFLAG': 0.0,      'FDF4FTFLAG': 0.0,
           'FDF1XN': 0.0,               'FDF2XN': 0.0,              'FDF3XN': 0.0,          'FDF4XN': 0.0,
           'FDF1LB': 0.0,               'FDF2LB': 0.0,
           'FDYEAR': 0.0,       'FDMONTH': 0.0,     'FDDAY': 0.0,       'FDHOURS': 0.0,     'FDMINS': 0.0,      'FDSECS': 0.0,
           'FDUSERNAME': '',    'FDUSER1': 0.0,     'FDUSER2': 0.0,     'FDUSER3': 0.0,     'FDUSER4': 0.0,     'FDUSER5': 0.0,
           'FDCOMMENT': '',     'FDTITLE': '',      'FDSRCNAME': '',    'FDOPERNAME': '',   'FDSLICECOUNT': 0,  'FDPIPECOUNT': 0.0,
           'FDTEMPERATURE': 0.0,'FDNOISE': 0.0,     'FDTAU': 0.0,       'FDTRANSPOSED': 0.0,'FDRANK': 0.0,      'FDMAGIC': 0.0,
           'FDMIN': 0.0,        'FDMAX': 0.0,       'FDDISPMIN': 0.0,   'FDDISPMAX': 0.0,   'FDFIRSTPLANE': 0.0,'FDLASTPLANE': 0.0,
           'FDLASTBLOCK': 0.0,  'FD1DBLOCK': 0.0,   'FDHISTBLOCK': 0.0, 'FDBASEBLOCK': 0.0, 'FDCONTBLOCK': 0.0, 'FDBMAPBLOCK': 0.0,
           'FDPEAKBLOCK': 0.0,  'FDQUADFLAG': 0.0,  'FDMCFLAG': 0.0,    'FDPIPEFLAG': 0.0,  'FDSCALEFLAG': 0.0, 'FDPLANELOC': 0.0,
           'FDPARTITION': 0.0,   'FDNUSDIM': 0.0,   'FDCUBEFLAG': 0.0}
    return dic