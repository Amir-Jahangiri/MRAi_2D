import nmrglue as ng
import numpy as np
import gc
#####################################################################
# process the direct dimension
def FT_DD(dic_fid,data_fid):
    dic, data = ng.pipe_proc.sp(dic_fid.copy(), data_fid, off=0.48, end=0.95, pow=2, c=0.5)
    dic, data = ng.pipe_proc.zf(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data)
    dic_ft, data_ft = ng.pipe_proc.di(dic, data)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

# process the indirect dimension
def FT_ID(dic_fid,data_fid,MODE=0):
    dic, data = ng.pipe_proc.tp(dic_fid.copy(), data_fid)
    if MODE ==0: dic, data = ng.pipe_proc.sp(dic, data, off=0.48, end=0.95, pow=2, c=0.5)
    dic, data = ng.pipe_proc.zf(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data)
    dic, data = ng.pipe_proc.di(dic, data)
    dic_ft, data_ft = ng.pipe_proc.tp(dic, data)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

def FT_processing(dic_fid,data_fid,MODE=0):
    dic, data = FT_DD(dic_fid,data_fid)
    dic_ft, data_ft = FT_ID(dic, data,MODE)
    del dic, data
    gc.collect()
    return dic_ft, data_ft

# invert process the indirect dimension
def iFT_ID(dic_fid,data_fid,MODE=0):
    dic, data = ng.pipe_proc.tp(dic_fid.copy(), data_fid)
    dic, data = ng.pipe_proc.ht(dic, data, auto=True)
    dic, data = ng.pipe_proc.ft(dic, data, inv=True)
    dic, data = ng.pipe_proc.zf(dic, data, inv=True)
    if MODE ==0: dic, data = ng.pipe_proc.sp(dic, data, inv=True, hdr=True)
    dic_ft, data = ng.pipe_proc.tp(dic, data)
    data_ft = np.zeros((2*data.shape[0],data.shape[1]),dtype='float32')
    for i in range(len(data)):
        data_ft[2*i+1,:] = data[i,:].imag
        data_ft[2*i,:] = data[i,:].real
    del dic, data
    gc.collect()
    return dic_ft, data_ft
#####################################################################
def parameters_creator(J, a_range, omega_range, tau_range, phi_range):
    Dim = tau_range.shape[0]
    a = np.random.uniform(a_range[0], a_range[1], (J,))
    omega = np.random.uniform(omega_range[0], omega_range[1],(J,Dim))
    tau = np.random.uniform(tau_range[0,0], tau_range[0,1], (J,Dim))
    for i in range(1,Dim):
        tau[:,i] = np.random.uniform(tau_range[i,0],tau_range[i,1], J)
    phi = np.random.normal(phi_range[0], phi_range[1], (J,Dim))
    del Dim
    gc.collect()
    return a, omega, tau, phi

def FID_creator(J, a, omega, tau, phi, N_O_P):
    def fid(OM,TA,PH,t):
        return np.exp(1j*(2*np.pi*OM*t+PH))*np.exp(-t*TA)
    t_0 = np.arange(0, N_O_P[0])
    t_1 = np.arange(0, N_O_P[1])
    X = np.zeros((2*N_O_P[0],N_O_P[1]), dtype=complex)
    for j in range(J):
        X_0 = fid(omega[j,0],tau[j,0],phi[j,0],t_0)
        X_1 = a[j]*fid(omega[j,1],tau[j,1],phi[j,1],t_1)
        for k in range(N_O_P[0]):  
            X[2*k,:] += X_0.real[k]*X_1
            X[2*k+1,:] += X_0.imag[k]*X_1
    del t_0, t_1, X_0, X_1, j,k
    gc.collect()
    return X

def noise_creator(N_O_P):
    size = 2*np.array(N_O_P)
    size[-1] *= 0.5
    noise = np.random.normal(size=size.astype(int)) +1j*np.random.normal(size=size.astype(int))
    del size
    gc.collect()
    return noise

def data_Full(N_O_P,J,a_range,omega_range,tau_range,phi_range,SNR,MODE=0):
    a, omega, tau, phi = parameters_creator(J, a_range, omega_range, tau_range, phi_range)
    FID = FID_creator(J, a, omega, tau, phi, N_O_P)
    noise = noise_creator(N_O_P)
    dic,S = FT_processing(dic_generator(N_O_P),FID,MODE)
    dic,N = FT_processing(dic_generator(N_O_P),noise,MODE)
    N *= np.max(S)/(np.std(N)*SNR)
    S += N
    del a, omega, tau, phi, FID, noise, N
    gc.collect()
    return dic, S

#####################################################################
def dic_generator(N_O_P):
    dic = ng.pipe.create_empty_dic()
    dic['FDDIMCOUNT'] = dic['FD2DPHASE'] = 2.0
    dic['FDSPECNUM'] = 2*N_O_P[0]
    dic['FDSIZE'] = dic['FDREALSIZE'] = N_O_P[1]
    dic['FDF1APOD'] = dic['FDF1TDSIZE'] = N_O_P[0]
    dic['FDF2APOD'] = dic['FDF2TDSIZE'] = N_O_P[1]
    dic['FDF1SW'] = dic['FDF2SW'] = dic['FDSCALEFLAG'] = dic['FDPIPECOUNT'] = 1.0
    dic['FDF1QUADFLAG'] = dic['FDF2QUADFLAG'] = dic['FDF1CENTER'] = dic['FDF2CENTER'] = 0.0
    return dic
