import numpy as np
#####################################################################
# US to NUS
def US_to_NUS(S,NUS_table):
    X = np.fft.ifft(S,axis=0)
    y = np.zeros_like(X)
    y[NUS_table] = X[NUS_table]
    y[y.shape[0]- NUS_table[NUS_table !=0]] = X[X.shape[0]- NUS_table[NUS_table !=0]]
    return np.array(np.fft.fft(y,axis=0).real,dtype='float32')
#####################################################################
# US to ECHO
def VE_to_E(S_VE):
    fid = np.fft.ifft(np.fft.ifft(S_VE,axis=0),axis=1)
    fid[0,:] *= 0.5
    fid[:,0] *= 0.5
    fid[0,0] *= 2
    fid[1:int(fid.shape[0]/2),int(fid.shape[1]/2):] = 0
    fid[int(fid.shape[0]/2):,1:int(fid.shape[1]/2)] = 0
    return np.fft.fft(np.fft.fft(fid,axis=0),axis=1).real
# US to Anti_ECHO
def VE_to_AE(S_VE):
    fid = np.fft.ifft(np.fft.ifft(S_VE,axis=0),axis=1)
    fid[0,:] *= 0.5
    fid[:,0] *= 0.5
    fid[0,0] *= 2
    fid[1:int(fid.shape[0]/2),1:int(fid.shape[1]/2)] = 0
    fid[int(fid.shape[0]/2):,int(fid.shape[1]/2):] = 0
    return np.fft.fft(np.fft.fft(fid,axis=0),axis=1).real
#####################################################################
# first change Echo_A_E to Complex then:
def Complex_to_E(data):
    for i in range(int(data.shape[0]/2)):
        data[2*i,:] = -data[2*i+1,:].imag
        data[2*i+1,:] = data[2*i+1,:].real
    return data

def Complex_to_AE(data):
    for i in range(int(data.shape[0]/2)):
        data[2*i+1,:] = -data[2*i,:].real
        data[2*i,:] = -data[2*i,:].imag
    return data

#####################################################################
# flip:
def flip(Anti,axis=0):
    return np.fft.fft(np.conjugate(np.fft.ifft(Anti,axis=axis)),axis=axis).real
