import numpy as np
#####################################################################
# Poisson_Gap
def poisson(lmbd):
    L = np.exp(-lmbd)
    k = 1
    p = np.random.random_sample()
    while p >= L:
        p *= np.random.random_sample()
        k += 1
    return k - 1 

def Poisson_Gap(N_of_point,N_signal_point):
    p = N_of_point
    z = N_signal_point
    ld = z/p
    w = 2*(ld-1)
    v = np.zeros((z,1),int)

    i = 0
    k = 0
    while i<z:
        v[k,0] = i
        i += 1
        k += 1
        i += poisson(w*np.sin((i+0.5)/(z+1)*(np.pi/2)))
    if k > p:
        w *=1.02
    if k < p:
        w /= 1.02

    while k != p:
        i = 0
        k = 0
        while i<z:
            v[k,0] = i
            i += 1
            k += 1
            i += poisson(w*np.sin((i+0.5)/(z+1)*(np.pi/2)))
        if k > p:
            w *=1.02
        if k < p:
            w /= 1.02
    U_poisson_gap = v[:p,0]
    return U_poisson_gap

def NS(N_of_point,N_signal_point,kind):
    if kind == "PG":
        ind_NUS = Poisson_Gap(N_of_point,N_signal_point)
    if kind == "FR":
        ind_NUS = np.random.choice(N_signal_point, replace=False , size=N_of_point)   # Get random indices
    ind_NUS = np.sort(ind_NUS)
    return ind_NUS