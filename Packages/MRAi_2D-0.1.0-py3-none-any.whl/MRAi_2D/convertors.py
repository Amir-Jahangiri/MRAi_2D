import numpy as np
import gc
#####################################################################
# US to VE
def US_VE(ref,Size):
    X = np.zeros((Size,int(ref.shape[1])),dtype=complex)
    for i in range(min(Size,int(ref.shape[0]/2))):
        X[i,:] = ref[2*i,:]+1j*ref[2*i+1,:]
    X_VE = np.zeros((2*X.shape[0]-1,X.shape[1]), dtype=complex)
    for i in range(1,X.shape[0]):
        X_VE[i,:] = X[i,:] 
        X_VE.real[X.shape[0]+i-1,:] = X.real[X.shape[0]-i,:]
        X_VE.imag[X.shape[0]+i-1,:] = -X.imag[X.shape[0]-i,:]
    X_VE[0,:] = X[0,:]
    return np.fft.fft(X_VE,axis=0).real
# US to NUS
def US_to_NUS(S,NUS_table):
    X = np.fft.ifft(S,axis=0)
    y = np.zeros_like(X)
    y[NUS_table] = X[NUS_table]
    y[y.shape[0]- NUS_table[NUS_table !=0]] = X[X.shape[0]- NUS_table[NUS_table !=0]]
    return np.array(np.fft.fft(y,axis=0).real,dtype='float32')
#####################################################################
# US to ECHO
def VE_to_E(S_VE):
    fid = np.fft.ifft(np.fft.ifft(S_VE,axis=0),axis=1)
    fid[0,:] *= 0.5
    fid[:,0] *= 0.5
    fid[0,0] *= 2
    fid[1:int(fid.shape[0]/2),int(fid.shape[1]/2):] = 0
    fid[int(fid.shape[0]/2):,1:int(fid.shape[1]/2)] = 0
    return np.fft.fft(np.fft.fft(fid,axis=0),axis=1).real
# US to Anti_ECHO
def VE_to_AE(S_VE):
    fid = np.fft.ifft(np.fft.ifft(S_VE,axis=0),axis=1)
    fid[0,:] *= 0.5
    fid[:,0] *= 0.5
    fid[0,0] *= 2
    fid[1:int(fid.shape[0]/2),1:int(fid.shape[1]/2)] = 0
    fid[int(fid.shape[0]/2):,int(fid.shape[1]/2):] = 0
    return np.fft.fft(np.fft.fft(fid,axis=0),axis=1).real
#####################################################################
def split_spect_slid(S,Slid,step=1,MODE=0):
    if MODE ==0:
        S = np.pad(S,((int(S.shape[0]/2), int(S.shape[0]/2)-1),(int(Slid/2), int(Slid/2))), 'wrap')
    else:
        Slid = 1
    Nj = int((S.shape[1]-Slid)/step)+1
    S_data = np.zeros((Nj,S.shape[0],Slid))
    for j in range(Nj):
        S_data[j] = np.roll(S, (0, -j*step), axis=(0, 1))[:,:Slid]
    return S_data

def split_spect_Box(S,win_size_1,win_size_2,step_1,step_2,MODE=0):
    Ni = int((S.shape[0]-win_size_1)/step_1)+1
    Nj = int((S.shape[1]-win_size_2)/step_2)+1
    if MODE == 0:
        S = np.pad(S,((int(win_size_1/2), int(win_size_1/2)-1),(int(win_size_2/2), int(win_size_2/2)-1)), 'wrap')
        win_size_1 = 2*win_size_1-1
        win_size_2 = 2*win_size_2-1
    S_data = np.zeros((Ni*Nj,win_size_1,win_size_2))
    for i in range(Ni):
        for j in range(Nj):
            S_data[i*Nj+j] = np.roll(S, (-i*step_1, -j*step_2), axis=(0, 1))[:win_size_1,:win_size_2]
    return S_data

def merge_spect(S,N_signal_point_1,N_signal_point_2):
    S_data = np.zeros((N_signal_point_1,N_signal_point_2))
    Ni = int(N_signal_point_1/S.shape[1])
    Nj = int(N_signal_point_2/S.shape[2])
    for i in range(Ni):
        for j in range(Nj):
            S_data[i*S.shape[1]:(i+1)*S.shape[1],j*S.shape[2]:(j+1)*S.shape[2]] = S[i*Nj+j]
    return S_data
