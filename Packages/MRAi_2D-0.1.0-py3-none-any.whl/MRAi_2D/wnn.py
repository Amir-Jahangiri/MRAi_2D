import tensorflow as tf
import tensorflow_probability as tfp
import numpy as np
import gc
#####################################################################
# Python code for building 1D WNN
def WNN_1D(Size,sliding_window,filter,LR):
    I = np.log2(Size).astype(int)
    input = tf.keras.layers.Input(shape = [2*Size-1, sliding_window])
    x = tf.concat([input, input], 1)
    x = tf.keras.layers.Reshape((x.shape[1],1,x.shape[2]))(x)
    for dil in range(I+1):
        x = tf.keras.layers.Conv2D(filter, kernel_size = (2,1), dilation_rate = (2**dil,1))(x)
        x = tf.keras.activations.relu(x, alpha = 0.2)
    x = tf.keras.layers.Conv2D(filters = sliding_window, kernel_size = (1,1))(x)
    output = tf.keras.layers.Reshape((2*Size-1, sliding_window))(x)
    model = tf.keras.Model(inputs = input, outputs = output)
    model.compile(loss = tf.keras.losses.Huber(), optimizer = tf.keras.optimizers.Adam(learning_rate = LR))
    return model

# Python code for building 2D WNN
def WNN_2D(Size,filter,LR):
    I = np.log2(Size).astype(int)
    input = tf.keras.layers.Input(shape = [2*Size-1, 4*Size-1])
    x = tf.keras.layers.Reshape((input.shape[1],input.shape[2],1))(input)
    x = tf.keras.layers.Conv2D(filter, kernel_size = (2,4))(x)
    x = tf.keras.activations.relu(x)
    for dil in range(1,I-1):
        x = tf.keras.layers.Conv2D(filter, kernel_size = (2,2),dilation_rate = (2**dil,2**(dil+1)))(x)
        x = tf.keras.activations.relu(x)
    x = tf.keras.layers.Conv2D(1, kernel_size=(2,2),dilation_rate = (2**(dil+1),2**(dil+2)))(x)
    output = tf.keras.layers.Reshape((Size, 2*Size))(x)
    model = tf.keras.Model(inputs = input, outputs = output)
    model.compile(loss = tf.keras.losses.MeanSquaredError(), optimizer = tf.keras.optimizers.Adam(learning_rate = LR))
    return model
    
# Python code for building 2D WNN for uncertainty estimation
def NLL(y, distr):
    return -distr.log_prob(y)
def my_dist(params):
    return tfp.distributions.Normal(loc=params[...,0], scale=params[...,1])# both parameters are learnable
def WNN_2D_Uncertainty(Size,filter,LR):
    I = np.log2(Size).astype(int)
    input = tf.keras.layers.Input(shape = [2*Size-1, 4*Size-1])
    x = tf.keras.layers.Reshape((input.shape[1],input.shape[2],1))(input)
    x = tf.keras.layers.Conv2D(filter, kernel_size = (2,4))(x)
    x = tf.keras.activations.relu(x)
    for dil in range(1,I-1):
        x = tf.keras.layers.Conv2D(filter, kernel_size = (2,2),dilation_rate = (2**dil,2**(dil+1)))(x)
        x = tf.keras.activations.relu(x)
    x = tf.keras.layers.Conv2D(1, kernel_size=(2,2),dilation_rate = (2**(dil+1),2**(dil+2)))(x)
    std = 1e-3 + tf.keras.activations.relu(1e-2 * x)
    output_std = tf.keras.layers.Reshape((Size, 2*Size))(std)
    
    input_2 = tf.keras.layers.Input(shape = [Size, 2*Size])
    mean = tf.keras.layers.Reshape((input_2.shape[1],input_2.shape[2],1))(input_2)
    output_mean = tf.keras.layers.Reshape((Size, 2*Size))(mean)
    
    params = tf.keras.layers.Concatenate()([mean,std])
    dist = tfp.layers.DistributionLambda(my_dist)(params)
    model = tf.keras.Model(inputs = [input,input_2], outputs = dist)
    model.compile(loss = NLL, optimizer = tf.keras.optimizers.Adam(learning_rate = LR))
    model_std = tf.keras.Model(inputs=input, outputs=output_std)
    model_mean = tf.keras.Model(inputs=input_2, outputs=output_mean)
    return [model, model_std, model_mean]

#####################################################################
def predicting(tests,dirc,BS,MODE=0):
    Norm = np.linalg.norm(tests, axis = (1,2))
    test_s = np.array(tests/Norm[:,None,None])
    model = tf.keras.models.load_model(dirc)
    preds = model.predict(test_s,batch_size=BS)
    if MODE  != 0: preds = preds[0]    
    Norm *= np.sqrt(preds.size/test_s.size)
    preds = preds * Norm[:,None,None]
    del Norm,test_s,model
    gc.collect()
    return preds
