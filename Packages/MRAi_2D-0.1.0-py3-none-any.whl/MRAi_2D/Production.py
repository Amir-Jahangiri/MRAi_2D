import numpy as np
import MRAi_2D as ma
import gc

#####################################################################    
def NUS_Rec(VE,NUS_table,NUS,dirc,Size=128,sliding_win=3,DNN=15,BS=64):
    K = VE.shape[1]
    tests = np.zeros((K,2*Size-1,sliding_win))
    for k in range(K):
        tests[k,:,0] = VE[:,k-1]
        tests[k,:,1] = VE[:,k]
        tests[k,:,2] = VE[:,0 if k==K-1 else k+1]
    pred = np.array(tests/NUS)
    for dnn in range(DNN):
        pred = ma.wnn.predicting(pred,dirc+"DNN_"+str(dnn),BS)
        for k in range(K):
            pred[k] -= ma.convertors.US_to_NUS(pred[k],NUS_table)
        pred += tests
    pred = np.fft.ifft(pred,axis=1)[:,:Size,1]
    pred = np.transpose(pred)
    pred_S = np.zeros((2*Size,K))
    for i in range(Size):
        pred_S[2*i+1,:] = pred[i,:].imag
        pred_S[2*i,:] = pred[i,:].real
    del tests,pred
    gc.collect()
    return pred_S
    
def VD_ID(VE,dirc,Size=256,sliding_win=3,BS=64):
    K = VE.shape[1]
    tests = np.zeros((K,2*Size-1,sliding_win))
    for k in range(K):
        tests[k,:,0] = VE[:,k-1]
        tests[k,:,1] = VE[:,k]
        tests[k,:,2] = VE[:,0 if k==K-1 else k+1]
    pred = ma.wnn.predicting(tests,dirc+"DNN_0",BS,1)
    pred = np.fft.ifft(pred,axis=1)[:,:Size,1]
    pred = np.transpose(pred)
    pred_S = np.zeros((2*Size,K))
    for i in range(Size):
        pred_S[2*i+1,:] = pred[i,:].imag
        pred_S[2*i,:] = pred[i,:].real
    del tests,pred
    gc.collect()
    return pred_S

def Echo_Rec(tests_data,dirc,Size=32,DNN=5,BS=64):
    pred_S = np.array(tests_data)
    for dnn in range(DNN):
        tests = ma.convertors.split_spect_Box(pred_S,Size,2*Size,Size,2*Size)
        pred = ma.wnn.predicting(tests,dirc+"DNN_"+str(dnn),BS)
        pred_S = ma.convertors.merge_spect(pred,tests_data.shape[0],tests_data.shape[1])
        if dnn!=DNN-1: pred_S *= (1-0.05*2**(-dnn))
        pred_S -= ma.convertors.VE_to_E(pred_S)
        pred_S += tests_data
    del tests,pred
    gc.collect()
    return pred_S

def Uncertainty(tests_data,dirc,Size=32,BS=64):
    tests = ma.convertors.split_spect_Box(tests_data,Size,2*Size,Size,2*Size)
    pred = ma.wnn.predicting(tests,dirc+"DNN_0",BS)
    pred_S = ma.convertors.merge_spect(pred,tests_data.shape[0],tests_data.shape[1])
    del tests,pred
    gc.collect()
    return pred_S



